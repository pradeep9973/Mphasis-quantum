# Configuration file for the Sphinx documentation builder.
#
# This file only contains a selection of the most common options. For a full
# list see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Path setup --------------------------------------------------------------

# If extensions (or modules to document with autodoc) are in another directory,
# add these directories to sys.path here. If the directory is relative to the
# documentation root, use os.path.abspath to make it absolute, like shown here.
#
import sys

import sphinx_rtd_theme

sys.path.append('../..')
import singularity.optimization

# The master toctree document.
master_doc = "index"

# -- Project information -----------------------------------------------------

project = "Multiverse Singularity Optimization"
copyright = "2019-2022, Multiverse Computing"
author = "Multiverse Computing"

# The full version, including alpha/beta/rc tags
release = singularity.optimization.__version__
version = singularity.optimization.__version__

# -- General configuration ---------------------------------------------------

# Add any Sphinx extension module names here, as strings. They can be
# extensions coming with Sphinx (named 'sphinx.ext.*') or your custom
# ones.
extensions = [
    "myst_parser",
    "sphinx.ext.autodoc",
    "sphinx.ext.doctest",
    "sphinx.ext.intersphinx",
    "sphinx.ext.todo",
    "sphinx.ext.coverage",
    "sphinx.ext.mathjax",
    "sphinx.ext.ifconfig",
    "sphinx.ext.viewcode",
    "sphinx.ext.githubpages",
    "sphinx.ext.napoleon",
]

# Add any paths that contain templates here, relative to this directory.
templates_path = ["_templates"]

# List of patterns, relative to source directory, that match files and
# directories to ignore when looking for source files.
# This pattern also affects html_static_path and html_extra_path.
exclude_patterns = [ "*onlyinfull*", "*advanced-usage*", "*hideme*", "*internal*" ]
import os

if os.environ.get("FULL_BUILD"):
    exclude_patterns = []
    tags.add("internal")

autodoc_member_order = "bysource"
# autodoc_type_aliases = {
#     'Constraint': 'singularity.optimization.Constraint',
#     'Model': 'singularity.optimization.Model',
#     'Objective': 'singularity.optimization.Objective',
#     'Expression': 'singularity.optimization.Expression',
#     'Solution': 'singularity.optimization.Solution',
#     'OptimizationResult': 'singularity.optimization.OptimizationResult',
#     'Variable': 'singularity.optimization.Variable',
#     'SymbolicExpression': 'singularity.optimization.SymbolicExpression',
#     'List': 'List',
#     'symengine.lib.symengine_wrapper.Expr': 'singularity.optimization.SymbolicExpression',
# }

# -- Options for HTML output -------------------------------------------------

# The theme to use for HTML and HTML Help pages.  See the documentation for
# a list of builtin themes.
#
html_theme = "sphinx_rtd_theme"
html_theme_path = [sphinx_rtd_theme.get_html_theme_path()]
html_copy_source = False
html_show_sourcelink = False

# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "default.css" will overwrite the builtin "default.css".
html_static_path = ["_static"]
html_logo = "_static/logo.jpg"
html_css_files = ["custom.css"]
html_js_files = ['versions.js']

try:
   html_context
except NameError:
   html_context = dict()
html_context['downloads'] = list()
html_context['downloads'].append( ('pdf', f'../multiverse-singularity-optimization-internal-docs-{version}.pdf'))
html_context['downloads'].append( ('external-pdf', f'../multiverse-singularity-optimization-docs-{version}.pdf'))
html_context['downloads'].append( ('html', f'../multiverse-singularity-optimization-internal-docs-{version}.zip'))
html_context['downloads'].append( ('external-html', f'../multiverse-singularity-optimization-docs-{version}.zip'))
 
