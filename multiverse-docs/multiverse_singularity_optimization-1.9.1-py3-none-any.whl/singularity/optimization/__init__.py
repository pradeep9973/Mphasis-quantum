# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

# flake8: noqa

__version__ = "1.9.1"

from singularity.optimization.modelling.constraint import Constraint
from singularity.optimization.modelling.model import Model
from singularity.optimization.modelling.objective import Objective
from singularity.optimization.modelling.variable import BINARY, INTEGER, Variable
from singularity.optimization.optimization.result import OptimizationResult
from singularity.optimization.optimization.solution import Solution
