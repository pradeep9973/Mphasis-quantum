# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

import itertools
from operator import attrgetter
from typing import Dict, Iterable, List, Tuple, Union

import symengine

SymbolicExpression = Union[symengine.Expr]


def split_expressions(
    expressions: Union[SymbolicExpression, Tuple[SymbolicExpression]]
) -> Tuple[SymbolicExpression]:
    """Return all the atoms present in a set symbolic expressions."""
    if all(map(attrgetter("is_Atom"), expressions)):
        return expressions
    else:
        return split_expressions(tuple(itertools.chain.from_iterable(map(_atomise, expressions))))


def _atomise(x: SymbolicExpression) -> Iterable:
    if x.is_Atom:
        return (x,)
    elif x.is_Pow:
        return itertools.repeat(x.base, int(x.exp))
    else:
        return x.args


def group_by_power(expressions: List[SymbolicExpression]) -> Dict[int, List[Tuple]]:
    """Group the atoms by the polynomial power."""
    result_dict: Dict[int, List[Tuple]] = {}
    for expression in map(lambda x: (x,), expressions):
        splitted_expressions = split_expressions(expression)
        power = len(splitted_expressions)
        if power not in result_dict:
            result_dict[power] = [splitted_expressions]
        else:
            result_dict[power].append(splitted_expressions)

    return result_dict
