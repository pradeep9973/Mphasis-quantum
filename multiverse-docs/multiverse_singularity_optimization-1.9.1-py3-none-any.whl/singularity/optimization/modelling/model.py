# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

from __future__ import annotations

import asyncio
import io
import json
import logging
import os
from collections import defaultdict
from typing import Collection, Dict, List, Optional, Set, Tuple, Union

import nest_asyncio
import numpy as np
import scipy as sp

from singularity.optimization import __version__ as version
from singularity.optimization.backend import Backend
from singularity.optimization.io.constants import FEASIBILITY_TOL
from singularity.optimization.io.model_deserializer import deserialize_model
from singularity.optimization.io.model_serializer import serialize_model
from singularity.optimization.modelling.constraint import Constraint
from singularity.optimization.modelling.expression import group_by_power
from singularity.optimization.modelling.objective import Objective
from singularity.optimization.modelling.variable import INTEGER, Variable
from singularity.optimization.optimization.result import OptimizationResult
from singularity.optimization.optimization.solution import Solution

nest_asyncio.apply()

logger = logging.getLogger("singularity.optimization")

SOLVER_LIMITS = defaultdict(
    lambda: 100000,
    {
        "exhaustive": 17,
        "dwave_exact": 17,
        "dwave_hybrid": 1000000,
        "dwave_qpu": 3500,
        "simulated_annealing": 1000000,
        "classical": 999,
        "gurobi": 500000,
    },
)

SolutionArray = Union[tuple, np.ndarray]


class Model:
    """Defines an optimization model.

    Args:
        objective (Objective): The objective.
        constraints (Optional[Collection[Constraint]]): A list of constraints. (Optional)
    """

    def __init__(
        self,
        objective: Optional[Objective] = None,
        constraints: Optional[Union[Collection[Constraint], Constraint]] = None,
    ) -> None:
        """Initializes object with given parameters. Also adds a variable index."""
        self.linear_objective_vector: Optional[sp.sparse.csr_matrix] = None
        self.quadratic_objective_matrix: Optional[sp.sparse.csr_matrix] = None
        self.constant: Optional[float] = None
        self.sense: Optional[str] = None
        self.linear_constraint_matrix: Optional[sp.sparse.csr_matrix] = None
        self.constraint_lower_bounds: Optional[np.ndarray] = None
        self.constraint_upper_bounds: Optional[np.ndarray] = None
        self.penalty_strengths: Optional[np.ndarray] = None

        self.variable_index: Dict[Variable, int] = {}
        self.constraint_index: Dict[str, int] = {}

        if objective is not None:
            self.objective = objective
        else:
            self._objective = None

        if isinstance(constraints, Collection):
            self.add_constraints(constraints)
        elif isinstance(constraints, Constraint):
            self.add_constraint(constraints)
        else:
            self._constraints: List[Constraint] = []

    @property
    def num_variables(self) -> int:
        """Number of variables."""
        return len(self.variable_index)

    @property
    def num_constraints(self) -> int:
        """Number of constraints."""
        return len(self.constraint_index)

    @property
    def objective_type(self) -> str:
        """Objective type."""
        return "linear" if self.quadratic_objective_matrix is None else "quadratic"

    @property
    def constraint_type(self) -> str:
        """Constraint type."""
        return "box" if self.num_constraints == 0 else "linear"

    @property
    def variable_type(self) -> str:
        """Variable type."""
        return "integer" if INTEGER in (var.var_type for var in self.variables) else "binary"

    @property
    def constraints(self) -> List[Constraint]:
        """A list of constraints."""
        return self._constraints

    @property
    def variables(self) -> Set[Variable]:
        """The variables of the model."""
        return set(self.variable_index.keys())

    @property
    def variable_lower_bounds(self) -> np.ndarray:
        """A vector containing the lower bounds of variables."""
        lower_bounds = np.zeros(self.num_variables, dtype=np.int64)
        for variable, i in self.variable_index.items():
            lower_bounds[i] = variable.lb
        return lower_bounds

    @property
    def variable_upper_bounds(self) -> np.ndarray:
        """A vector containing the upper bounds of variables."""
        upper_bounds = np.zeros(self.num_variables, dtype=np.int64)
        for variable, i in self.variable_index.items():
            upper_bounds[i] = variable.ub
        return upper_bounds

    @property
    def objective(self) -> Optional[Objective]:
        """Symbolic representation of the model objective."""
        return self._objective

    @objective.setter
    def objective(self, objective) -> None:
        self._objective = objective
        self.variable_index = {variable: i for i, variable in enumerate(objective.variables)}
        coefficients_dict = self.objective.expression.as_coefficients_dict()
        self.constant = coefficients_dict.pop(1, 0)
        self.sense = self.objective.sense
        grouped_terms = group_by_power(coefficients_dict.keys())

        if not set(grouped_terms.keys()).issubset({1, 2}):
            raise ValueError("Objective contains terms of greater than quadratic order.")

        linear_terms = grouped_terms.get(1, [])
        quadratic_terms = grouped_terms.get(2, [])

        linear_objective_vector = sp.sparse.dok_matrix((1, self.num_variables), dtype=np.float64)
        for (var,) in linear_terms:
            linear_objective_vector[0, self.variable_index[var]] = float(coefficients_dict[var])
        self.linear_objective_vector = sp.sparse.csr_matrix(linear_objective_vector)

        if len(quadratic_terms) > 0:
            quadratic_objective_matrix = sp.sparse.dok_matrix(
                (self.num_variables, self.num_variables), dtype=np.float64
            )
            for var1, var2 in quadratic_terms:
                quadratic_objective_matrix[
                    self.variable_index[var1], self.variable_index[var2]
                ] = 2 * float(coefficients_dict[var1 * var2])
            self.quadratic_objective_matrix = sp.sparse.csr_matrix(quadratic_objective_matrix)

    def add_constraint(self, constraint: Constraint) -> None:
        """Appends a constraint to the list of constraints."""
        self.add_constraints([constraint])

    def add_constraints(self, constraints: Collection[Constraint]) -> None:
        """Appends a list of constraints to the list of constraints."""
        constraint_index_offset = self.num_constraints
        new_num_constraints = constraint_index_offset + len(constraints)
        for i, constraint in enumerate(constraints):
            if constraint.name in self.constraint_index.keys():
                raise ValueError(
                    f"There is already a constraint called {constraint.name} in the model."
                )
            self.constraint_index[constraint.name] = i + constraint_index_offset

        new_variables = set.union(*(constraint.variables for constraint in constraints)).difference(
            self.variables
        )
        self.add_variables(new_variables)

        lbs, exs, ubs = tuple(zip(*[constraint.as_tuple() for constraint in constraints]))
        penalty_strengths = [constraint.penalty_strength for constraint in constraints]

        if constraint_index_offset == 0:
            self._constraints = list(constraints)
            self.linear_constraint_matrix = sp.sparse.dok_matrix(
                (new_num_constraints, self.num_variables), dtype=np.float64
            )
            self.constraint_lower_bounds = np.array(lbs)
            self.constraint_upper_bounds = np.array(ubs)
            self.penalty_strengths = np.array(penalty_strengths, dtype=np.float64)
        else:
            self._constraints.extend(list(constraints))
            self.linear_constraint_matrix.resize((new_num_constraints, self.num_variables))
            self.linear_constraint_matrix = sp.sparse.dok_matrix(self.linear_constraint_matrix)
            self.constraint_lower_bounds = np.resize(
                self.constraint_lower_bounds, new_num_constraints
            )
            self.constraint_upper_bounds = np.resize(
                self.constraint_upper_bounds, new_num_constraints
            )
            self.penalty_strengths = np.resize(self.penalty_strengths, new_num_constraints)
            self.constraint_lower_bounds[constraint_index_offset:] = lbs
            self.constraint_upper_bounds[constraint_index_offset:] = ubs
            self.penalty_strengths[constraint_index_offset:] = penalty_strengths

        for i, ex in enumerate(exs):
            coefficients_dict = ex.as_coefficients_dict()
            coefficients_dict.pop(1, 0)  # Constant should be zero
            grouped_terms = group_by_power(coefficients_dict.keys())
            if not set(grouped_terms.keys()).issubset({1}):
                raise ValueError("Constraints contain terms of greater than linear order.")

            linear_terms = grouped_terms.get(1, [])
            for (var,) in linear_terms:
                self.linear_constraint_matrix[
                    i + constraint_index_offset, self.variable_index[var]
                ] = float(coefficients_dict[var])
        self.linear_constraint_matrix = sp.sparse.csr_matrix(self.linear_constraint_matrix)

    def add_variable(self, variable: Variable) -> None:
        """Adds a variable to the model."""
        self.add_variables([variable])

    def add_variables(self, variables: Collection[Variable]) -> None:
        # TODO: add unit test
        """Adds a list of variables to the model."""
        variable_index_offset = self.num_variables
        new_num_variables = variable_index_offset + len(variables)
        for i, variable in enumerate(variables):
            if variable in self.variables:
                raise ValueError("There is already a variable called {variable.name} in the model.")
            self.variable_index[variable] = i + variable_index_offset

        if self.linear_objective_vector is not None:
            self.linear_objective_vector.resize((1, new_num_variables))
        if self.quadratic_objective_matrix is not None:
            self.quadratic_objective_matrix.resize((new_num_variables, new_num_variables))
        if self.linear_constraint_matrix is not None:
            self.linear_constraint_matrix.resize((self.num_constraints, new_num_variables))

    @classmethod
    def from_quadratic_model(
        cls,
        linear_objective_vector: Optional[sp.sparse.csr_matrix] = None,
        quadratic_objective_matrix: Optional[sp.sparse.csr_matrix] = None,
        constant: float = 0,
        sense: str = "minimize",
        variable_type: str = "integer",
        linear_constraint_matrix: Optional[sp.sparse.csr_matrix] = None,
        constraint_lower_bounds: Optional[np.ndarray] = None,
        constraint_upper_bounds: Optional[np.ndarray] = None,
        variable_lower_bounds: np.ndarray = None,
        variable_upper_bounds: np.ndarray = None,
        penalty_strengths: Optional[np.ndarray] = None,
    ) -> Model:
        """
        Creates a new model from data specifying a quadratic model.

        The model is define as:
            min/max 0.5 * x^TQx + b^Tx + c
            such that: cl <= Ax <= cu,
            l <= x <= u

        Number of variables = N
        Number of constraints = M

        Args:
            linear_objective_vector (scipy.sparse.csr_matrix[1, N]): b.
            quadratic_objective_matrix (scipy.sparse.csr_matrix[N, N]): Q.
            constaint (float): c.
            sense (str): "minimize" or "maximize".
            variable_type (str): "binary" or "integer", if "binary" variables may be omitted.
            linear_constraint_matrix (scipy.sparse.csr_matrix[M, N]): A.
            constraint_lower_bounds (numpy.ndarray[M]): cl.
            constraint_upper_bounds (numpy.ndarray[M]): cu.
            variable_lower_bounds (numpy.ndarray[N]): l.
            variable_upper_bounds (numpy.ndarray[N]): u.
            penalty_strengths (numpy.ndarray[M]): Intial values for penalty strengths.

        Returns:
            A model.
        """
        model = Model()
        if linear_objective_vector is not None:
            num_variables = linear_objective_vector.shape[1]
        elif quadratic_objective_matrix is not None:
            num_variables = quadratic_objective_matrix.shape[0]
        elif linear_constraint_matrix is not None:
            num_variables = linear_constraint_matrix.shape[1]
        elif variable_lower_bounds is not None:
            num_variables = len(variable_lower_bounds)
        else:
            raise ValueError("Cannot infer model size.")

        if linear_constraint_matrix is not None:
            model.constraint_index = {
                f"constraint_row_{i}": i for i in range(linear_constraint_matrix.shape[0])
            }

        if variable_type != "binary":
            model.variable_index = {
                Variable(
                    f"x{i}",
                    var_type=INTEGER,
                    bounds=(variable_lower_bounds[i], variable_upper_bounds[i]),
                ): i
                for i in range(num_variables)
            }
        else:
            model.variable_index = {Variable(f"x{i}"): i for i in range(num_variables)}

        model.linear_objective_vector = linear_objective_vector
        model.quadratic_objective_matrix = quadratic_objective_matrix
        model.constant = constant
        model.sense = sense
        model.linear_constraint_matrix = linear_constraint_matrix
        model.constraint_lower_bounds = constraint_lower_bounds
        model.constraint_upper_bounds = constraint_upper_bounds
        model.penalty_strengths = penalty_strengths
        return model

    @classmethod
    def from_qubo(
        cls, qubo: Dict[Tuple[int, int], float], offset: float = 0, sense: str = "minimize"
    ) -> Model:
        """
        Creates a new model from a QUBO represented as a dictionary.

        Args:
            qubo: A dictionary where the keys denote the indices of a QUBO matrix and the values
                denote the coefficients.
            offset: The offset will be added to the objective.

        Returns:
            A model.
        """
        row_inds, col_inds = zip(*qubo.keys())
        index_mapping = {input_ind: i for i, input_ind in enumerate(set(row_inds + col_inds))}
        num_variables = len(index_mapping)
        quadratic_objective_matrix = sp.sparse.dok_matrix(
            (num_variables, num_variables), np.float64
        )
        for index, coeff in qubo.items():
            quadratic_objective_matrix[index_mapping[index[0]], index_mapping[index[1]]] = 2 * coeff

        model = Model()
        model.variable_index = {
            Variable(f"x{input_ind}"): i for input_ind, i in index_mapping.items()
        }
        model.quadratic_objective_matrix = sp.sparse.csr_matrix(quadratic_objective_matrix)
        model.constant = offset
        model.sense = sense
        return model

    def eval_constraints(
        self, solution: Union[SolutionArray, Dict[Variable, int]]
    ) -> Dict[str, bool]:
        """Evaluates if constraints are respected given variable values in a solution."""
        if isinstance(solution, dict):
            solution_array = np.zeros(self.num_variables, dtype=np.int64)
            for var, i in self.variable_index.items():
                try:
                    solution_array[i] = solution[var]
                except KeyError:
                    solution_array[i] = solution[var.name]
        else:
            solution_array = np.array(solution)

        constraint_values = self.linear_constraint_matrix @ solution_array
        lower_satisfied = self.constraint_lower_bounds - FEASIBILITY_TOL <= constraint_values
        upper_satisfied = self.constraint_upper_bounds + FEASIBILITY_TOL >= constraint_values
        return {
            constraint: lower_satisfied[i] and upper_satisfied[i]
            for constraint, i in self.constraint_index.items()
        }

    def eval_objective(self, solution: Union[SolutionArray, Dict[Variable, int]]) -> float:
        """Evaluates the model's objective function at the provided solution point."""
        if isinstance(solution, dict):
            solution_array = np.zeros(self.num_variables, dtype=np.int64)
            for var, i in self.variable_index.items():
                try:
                    solution_array[i] = solution[var]
                except KeyError:
                    solution_array[i] = solution[var.name]
        else:
            solution_array = np.array(solution)

        if self.linear_objective_vector is not None:
            linear_term = (self.linear_objective_vector @ solution_array)[0]
        else:
            linear_term = 0
        if self.quadratic_objective_matrix is not None:
            quadratic_term = 0.5 * (
                solution_array @ self.quadratic_objective_matrix @ solution_array
            )
        else:
            quadratic_term = 0
        return self.constant + linear_term + quadratic_term

    def _solution_cast(self, solution: dict) -> Solution:
        """Casts API solution to singularity solution object."""
        reverse_variable_index = {i: var for var, i in self.variable_index.items()}
        variables = {
            reverse_variable_index[int(variable[1:]) - 1]: value
            for variable, value in solution["qpu_readout"].items()
        }

        return Solution(
            variables=variables,
            objective_value=solution["energy"],
            is_feasible=solution["is_feasible"],  # This breaks compatibility with old solvers.
            num_occurrences=solution["num_occurrences"],
        )

    def _validate(self, solver: str) -> None:
        """Validate the model."""
        if self.num_variables > SOLVER_LIMITS[solver]:
            raise ValueError(
                f"Model size limit reached ({self.num_variables} variables)."
                + f" Solver: {solver} accepts a maximum of {SOLVER_LIMITS[solver]} variables."
            )

    def _as_dict(
        self, solver: str, num_solutions: int = 5, timeout: int = 1800, **solver_options
    ) -> dict:
        """Serializes the model to a python dictionary.

        Returns:
            dict: a json representable dictionary.
        """
        self._validate(solver)
        model_serialized = serialize_model(self)

        logger.info(f"Number of variables: {self.num_variables}")
        logger.info(f"Number of constraints: {self.num_constraints}")

        dwave_api_token: Optional[str] = solver_options.pop("dwave_api_token", None)

        return {
            "hyperparameters": {
                "solver": solver,
                "num_solutions": num_solutions,
                "timeout": timeout,
                "solver_options": solver_options,
                "version": version,
                "dwave_api_token": dwave_api_token,
            },
            "model": model_serialized,
            "num_variables": self.num_variables,
        }

    def _dump_json(self, json_file: str, solver: str, num_solutions: int = 5, **solver_options):
        with open(json_file, "w", encoding="UTF-8") as jf:
            json.dump(self._as_dict(solver, num_solutions, **solver_options), jf)

    @classmethod
    def from_json(cls, input_json: str | dict | io.TextIOWrapper) -> Tuple[Model, dict]:
        """Loads a job from JSON format into a `Model` object and optimizer kwargs.

        Args:
            input_json (str or dict or io.TextIOWrapper): The JSON file path, \
            JSON loaded as a dict, \
            or file-like object containing the model data.

        Returns:
            Model: The created `Model` object.
            dict: A dictionary containing the optimizer kwargs of the optimize method,
                including hyperparameters and solver options.
        """
        job_json = None
        if isinstance(input_json, str):
            with open(input_json, "r", encoding="UTF-8") as model_file:
                job_json = json.load(model_file)
        elif isinstance(input_json, dict):
            job_json = input_json
        elif isinstance(input_json, io.TextIOWrapper):
            job_json = json.load(input_json)

        timeout = job_json["hyperparameters"].get("timeout")
        num_solutions = job_json["hyperparameters"].get("num_solutions")
        solver = job_json["hyperparameters"].get("solver")
        solver_options = job_json["hyperparameters"].get("solver_options")

        optimize_kwargs: dict = {
            "solver": solver,
            "timeout": timeout,
            "num_solutions": num_solutions,
            **solver_options,
        }

        model = Model.from_quadratic_model(*deserialize_model(job_json["model"]))
        return model, optimize_kwargs

    def optimize(
        self,
        solver: str,
        num_solutions: int = 5,
        timeout: int = 1800,
        **solver_options,
    ) -> Union[None, OptimizationResult]:
        """Runs the optimization.

        Args:
            solver (str): The solver. See :ref:`sec-solvers` for the list of possible solvers.
            num_solutions (int): Number of solutions to return.
            timeout (int): Maximum number of seconds for the optimization to take.
            **solver_options: Available options depend on `solver`, see :ref:`sec-solvers`.

        Returns:
            OptimizationResult: Optimization result, containing solutions.
        """
        data = self._as_dict(solver, num_solutions, timeout, **solver_options)
        backend: Backend

        if os.getenv("USE_SOP_LOCAL_BACKEND") in ["True", "true"]:
            from singularity.optimization_backend.cli import optimize  # type: ignore

            result = optimize(data)
        else:
            import warnings

            classical_enum = "classical"
            experiment_enum = "tensor_network_experimental"
            if solver in [classical_enum, experiment_enum]:
                warnings.warn(f"{solver} is deprecated", DeprecationWarning, stacklevel=2)
            backend = Backend(service_request=solver)
            result = asyncio.run(backend.optimize(data, timeout=timeout))

        if result is not None:
            if result.get("values") is not None:  # this will be the default in v2.0.0
                reverse_variable_index = {i: var for var, i in self.variable_index.items()}
                variables = {
                    reverse_variable_index[int(variable[1:]) - 1]: value
                    for variable, value in result["values"].items()
                }
                samples = [self._solution_cast(sample) for sample in result.get("samples", [])]
                return OptimizationResult(
                    values=variables,
                    objective_value=result["objective_value"],
                    status=result.get("optimization_status"),
                    samples=samples,
                    runtime=result["runtime"],
                    details=result.get("info"),
                    sense=self.sense,
                )
            else:  # handle old solvers
                solutions = [self._solution_cast(solution) for solution in result["solutions"]]

                return OptimizationResult(
                    values=solutions[0].variables,  # type: ignore
                    objective_value=solutions[0].cost,
                    status=result.get("optimization_status"),
                    samples=solutions,
                    runtime=result["runtime"],
                    details=result.get("info"),
                )
        return None
