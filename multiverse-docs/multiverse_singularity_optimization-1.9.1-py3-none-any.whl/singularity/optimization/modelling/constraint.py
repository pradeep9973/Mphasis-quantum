# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

from typing import Set, Union

import symengine

from singularity.optimization.io.constants import INFINITY, NEGATIVE_INFINITY
from singularity.optimization.modelling.expression import SymbolicExpression
from singularity.optimization.modelling.variable import Variable


class Constraint:
    """Represents a constraint for a problem.

    Args:
        lhs (SymbolicExpression): The left-hand side of the constraint equation.
        operator (str): The operator of the constraint equation.
        rhs (Union[float, SymbolicExpression]): The right-hand side of the constraint equation.
        penalty_strength (float): The penalty strength for the constraint.
        name (str): The name of the constraint.
        inequality_precision (int): inequality precision value
    """

    def __init__(
        self,
        lhs: SymbolicExpression,
        operator: str,
        rhs: Union[float, SymbolicExpression],
        penalty_strength: float,
        name: str,
    ) -> None:
        """Initializes the object with given parameters"""
        self.lhs = lhs
        self.operator = operator
        self.rhs = rhs
        self.name = name
        self.penalty_strength = penalty_strength
        self.expression = symengine.Equality(lhs, rhs)

        if operator == "==":
            self.expression = symengine.Equality(lhs, rhs)
        elif operator == ">=":
            self.expression = symengine.GreaterThan(lhs, rhs)
        elif operator == "<=":
            self.expression = symengine.LessThan(lhs, rhs)
        else:
            raise ValueError("Invalid operator.")

        self.variables: Set[Variable] = self.expression.free_symbols

    @property
    def lhs(self) -> SymbolicExpression:
        """Left hand side of constraint expression."""
        return self._lhs

    @lhs.setter
    def lhs(self, expr: SymbolicExpression) -> None:
        self._lhs = expr.expand()

    @property
    def rhs(self) -> Union[float, SymbolicExpression]:
        """Right hand side of constraint expression."""
        return self._rhs

    @rhs.setter
    def rhs(self, expr: Union[float, SymbolicExpression]) -> None:
        if isinstance(expr, (float, int)):
            self._rhs = expr
        else:
            self._rhs = expr.expand()

    @property
    def penalty_strength(self) -> float:
        """Penalty strength for the constraint."""
        return self._penalty_strength

    @penalty_strength.setter
    def penalty_strength(self, value: float) -> None:
        if value < 0:
            raise ValueError("Penalty strength must be non-negative")
        self._penalty_strength = value

    def as_tuple(self):
        """Represent the constraint as a tuple `(lb, expr, ub)` corresponding to `lb<=expr<=ub`"""
        expr = (self.lhs - self.rhs).expand()
        constant = expr.as_coefficients_dict().get(1, 0)
        if self.operator == "==":
            return -constant, (expr - constant).expand(), -constant
        if self.operator == ">=":
            return -constant, (expr - constant).expand(), INFINITY
        if self.operator == "<=":
            return NEGATIVE_INFINITY, (expr - constant).expand(), -constant
