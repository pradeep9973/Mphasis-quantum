# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

from typing import Set

from singularity.optimization.modelling.expression import SymbolicExpression
from singularity.optimization.modelling.variable import Variable


class Objective:
    """Represents the optimization objective.

    Args:
        expression (SymbolicExpression): The expression to be minimized/maximized.
        sense (str): The optimization sense. Possible values are ``maximize`` and ``minimize``.
    """

    def __init__(
        self,
        expression: SymbolicExpression,
        sense: str,
    ) -> None:
        """Initializes the object based on the parameters. Sets variables from symbols."""
        self.expression = expression
        self.sense = sense
        self.variables: Set[Variable] = self.expression.free_symbols

    @property
    def expression(self) -> SymbolicExpression:
        """The expression."""
        return self._expression

    @expression.setter
    def expression(self, expr: SymbolicExpression) -> None:
        self._expression = expr.expand()

    @property
    def sense(self) -> str:
        """Getter for protected attribute _sense."""
        return self._sense

    @sense.setter
    def sense(self, value: str) -> None:
        if value not in ["maximize", "minimize"]:
            raise ValueError("Invalid optimization sense.")
        self._sense = value
