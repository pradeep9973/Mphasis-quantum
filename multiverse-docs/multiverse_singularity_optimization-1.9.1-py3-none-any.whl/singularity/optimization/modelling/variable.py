# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

from enum import Enum, auto
from typing import Optional, Tuple

import symengine


class VariableType(Enum):
    """Valid variable types."""

    BINARY = auto()
    INTEGER = auto()


BINARY = VariableType.BINARY
INTEGER = VariableType.INTEGER


class Variable(symengine.Symbol):
    """Represents a problem variable.

    Args:
        name (str): The name of the variable.
        var_type (VariableType): The type of the variable. Possible values are ``sop.BINARY`` or
            ``sop.INTEGER``.
        bounds (Optional[Tuple[int, int]]): The lower and upper bounds of the variable, in that
            order. It is required for integer variables.

    Examples::

          x1 = Variable("x1")
          x2 = Variable("x2", sop.INTEGER, (0, 10))

    """

    def __init__(
        self,
        name: str,
        var_type: Optional[VariableType] = BINARY,
        bounds: Optional[Tuple[int, int]] = None,
    ) -> None:
        """Initializes a variable and validates bounds."""
        super().__init__(name)
        if var_type == BINARY:
            self._var_type = var_type
            if bounds:
                raise ValueError("Binary type takes no bounds.")
        elif var_type == INTEGER:
            if not bounds:
                raise ValueError("Bounds must be specified for integer type.")
            self._var_type = var_type
            self._bounds = bounds
        else:
            raise TypeError("Invalid variable type.")

    @property
    def bounds(self) -> Tuple[int, int]:
        """Variable bounds."""
        return (0, 1) if self.var_type == BINARY else self._bounds

    @property
    def var_type(self) -> VariableType:
        """Variable type."""
        return self._var_type

    @property
    def ub(self) -> int:
        """Upper bound of the variable."""
        return self.bounds[1]

    @property
    def lb(self) -> int:
        """Lower bound of the variable."""
        return self.bounds[0]
