# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.


import asyncio
import dataclasses
import json
import logging
import os
from typing import Dict, Optional, Tuple

import requests

from singularity.optimization.exceptions import ERRORS_MAP, ErrorCode, SOPUnknownError


def read_json(file_path: str) -> Dict:
    """Reads a JSON file and returns it as a dict."""
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


@dataclasses.dataclass
class UrlCache:
    """Holds upload and download URL to be used as cache."""

    upload_url: str
    download_url: str


class Backend:
    """Handles communication with Singularity Optimization server."""

    def __init__(self, service_request: str = None):
        """Initialize backend with configurations for both user and system."""
        self.api_gateway = None
        self.backend_logger = logging.getLogger("singularity.optimization")
        self.config_user = self.get_user_config()
        self.service_request = service_request
        self.ssl_verify: bool = self.config_user.get("ssl_verify", True) not in {
            "False",
            "false",
            "0",
            "no",
            "No",
        }
        self.set_token_data(self.service_request)
        self.urls: Dict[str, UrlCache] = {}

    def get_user_config(self) -> Dict:
        """Loads configurations set by user."""
        home_path = os.path.expanduser("~")

        config_filename_singularity = "singularity_config.json"
        home_config_filename_singularity = os.path.join(home_path, config_filename_singularity)

        config: Dict[str, str] = {"optimization_endpoint": "https://sop.singularity-quantum.com"}

        for path in (
            home_config_filename_singularity,
            config_filename_singularity,
        ):
            if os.path.exists(path):
                self.backend_logger.debug(f"Reading token information from '{path}'.")
                config = {**config, **read_json(path)}

        if os.getenv("SINGULARITY_TOKEN"):
            self.backend_logger.debug(
                "Reading token information from 'SINGULARITY_TOKEN' environment variable."
            )
            config["token"] = os.getenv("SINGULARITY_TOKEN")

        if os.getenv("DWAVE_API_TOKEN"):
            self.backend_logger.debug(
                "Reading token information from 'DWAVE_API_TOKEN' environment variable."
            )
            config["dwave_api_token"] = os.getenv("DWAVE_API_TOKEN")

        if os.getenv("SINGULARITY_SSL_VERIFY"):
            self.backend_logger.debug(
                "Reading SSL verification option from 'SINGULARITY_SSL_VERIFY'"
                " environment variable."
            )
            config["ssl_verify"] = os.getenv("SINGULARITY_SSL_VERIFY")

        if os.getenv("SINGULARITY_OPTIMIZATION_ENDPOINT"):
            self.backend_logger.debug(
                "Reading endpoint from 'SINGULARITY_OPTIMIZATION_ENDPOINT' environment variable."
            )
            config["optimization_endpoint"] = os.getenv("SINGULARITY_OPTIMIZATION_ENDPOINT")

        if os.getenv("COMMON_IBM_TOKEN"):
            self.backend_logger.debug(
                "Reading token information from 'COMMON_IBM_TOKEN' environment variable."
            )
            config["common_ibm_token"] = os.getenv("COMMON_IBM_TOKEN")

        if os.getenv("COMMON_IBM_INSTANCE"):
            self.backend_logger.debug(
                "Reading token information from 'COMMON_IBM_INSTANCE' environment variable."
            )
            config["common_ibm_instance"] = os.getenv("COMMON_IBM_INSTANCE")

        if not config:
            raise Exception("Can't read user token.")

        return config

    def set_token_data(self, service_request) -> None:
        """Set configurations based on decoded id_token returned by server."""
        data = {"refresh_token": self.config_user["token"], "service_request": service_request}
        res = requests.post(
            self.config_user["optimization_endpoint"] + "/oauth",
            data=json.dumps(data),
            verify=self.ssl_verify,
        )

        if res.status_code != 200:
            raise Exception(f"Failed to authenticate: {res.text}")

        res = res.json()
        self.api_gateway = self.config_user["optimization_endpoint"]

    def _get_presigned_urls_and_job_id(self) -> Tuple[str, str, str]:
        """Returns pre-signed urls (for upload and download) and job_id"""
        headers = {
            "Content-Type": "application/json",
        }

        res = requests.post(
            f"{self.api_gateway}/generate-pre-signed-url", headers=headers, verify=self.ssl_verify
        )

        if res.status_code != 200:
            raise Exception(f"Generating upload and download url failed: {res.text}")

        response_data = res.json()

        self.urls[response_data["job_id"]] = UrlCache(
            upload_url=response_data["upload_url"],
            download_url=response_data["download_url"],
        )

        return (
            response_data["upload_url"],
            response_data["download_url"],
            response_data["job_id"],
        )

    def _upload_data(self, url: str, data: Dict) -> None:
        data_str = json.dumps(data, ensure_ascii=False)

        if len(data_str.encode("utf-8")) > (320 << 20):
            raise ValueError("Model size too large.")

        res = requests.put(url, data=data_str, verify=self.ssl_verify)

        if res.status_code != 200:
            raise Exception(f"Uploading model failed {res.content}")

        self.backend_logger.debug("Uploaded input JSON")

    def _submit_job(self, data: Dict) -> None:
        headers = {
            "Content-Type": "application/json",
        }
        # If dwave_api_token or IBM credentials were not passed as a function
        # targument to model.optimize hen use the value set in the environment_variables
        if not data["dwave_api_token"]:
            data["dwave_api_token"] = self.config_user.get("dwave_api_token")
        if not data["common_ibm_token"]:
            data["common_ibm_token"] = self.config_user.get("common_ibm_token")
        if not data["common_ibm_instance"]:
            data["common_ibm_instance"] = self.config_user.get("common_ibm_instance")

        res = requests.post(
            f"{self.api_gateway}/optimize", json=data, headers=headers, verify=self.ssl_verify
        )

        if res.status_code != 200:
            raise Exception(f"Failed to start optimization: {res.text}")

    async def optimize(self, data: dict, poll_interval: float = 0.3, timeout: int = 1800) -> Dict:
        """Uploads the problem to server and returns the solution returned by the server."""
        self.backend_logger.debug("Generating pre-signed URL.")
        upload_url, download_url, job_id = self._get_presigned_urls_and_job_id()

        dwave_api_token: Optional[str] = data["hyperparameters"].pop("dwave_api_token", None)
        common_ibm_token: Optional[str] = data["hyperparameters"].pop("common_ibm_token", None)
        common_ibm_instance: Optional[str] = data["hyperparameters"].pop(
            "common_ibm_instance", None
        )

        self.backend_logger.info(f"JOB ID: {job_id}")

        self.backend_logger.debug("Uploading data.")
        self._upload_data(upload_url, data)

        self.backend_logger.debug("Submitting optimization task...")

        self._submit_job(
            data={
                "job_id": job_id,
                "hyperparameters": data["hyperparameters"],
                "num_variables": data["num_variables"],
                "dwave_api_token": dwave_api_token,
                "common_ibm_token": common_ibm_token,
                "common_ibm_instance": common_ibm_instance,
            }
        )

        self.backend_logger.debug("Waiting for solution...")
        try:
            result = await asyncio.wait_for(
                self._poll_for_result(job_id, poll_interval), timeout=timeout
            )
        except asyncio.TimeoutError:
            raise ERRORS_MAP[ErrorCode.TIMEOUT_ERROR]

        return result

    async def _poll_for_result(self, job_id: str, poll_interval: float) -> Dict:
        result = None
        while not result:
            await asyncio.sleep(poll_interval)
            result = self._get_results(job_id)

        if result["status"] in ERRORS_MAP:
            raise ERRORS_MAP[result["status"]](message=result["error_message"])

        if result["status"] != "OK" or "solutions" not in result:
            raise SOPUnknownError(message=f"Unknown error, result is {result}")

        return result

    def _get_results(self, job_id: str) -> Optional[Dict]:
        response = requests.get(self.urls[job_id].download_url, verify=self.ssl_verify)
        return response.json() if response.status_code == 200 else None
