# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

INFINITY = 10**20
NEGATIVE_INFINITY = -(10**20)
FEASIBILITY_TOL = 10**-6
