# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

from collections import defaultdict
from typing import DefaultDict, Iterator, List, Tuple

import numpy as np
import scipy as sp


def _read_next_values(split_input: Iterator) -> List[str]:
    line = next(split_input)
    while line == "" or line[0] in ["!", "#", "%"]:
        line = next(split_input)
    return line.split()


def _parse_linear_coefficients(split_input: Iterator, num_variables: int) -> sp.sparse.csr_matrix:
    default_linear_coefficient = float(_read_next_values(split_input)[0])
    n_non_default_linear_terms = int(_read_next_values(split_input)[0])
    linear_coefficients = np.full((1, num_variables), default_linear_coefficient, dtype=float)
    for _ in range(n_non_default_linear_terms):
        i, v = _read_next_values(split_input)[:2]
        linear_coefficients[0, int(i) - 1] = float(v)

    return sp.sparse.csr_matrix(linear_coefficients)


def _parse_linear_constraint_coefficients(
    split_input: Iterator, num_variables: int, num_constraints: int
) -> sp.sparse.csr_array:
    linear_constraint_coefficients = sp.sparse.dok_array(
        (num_constraints, num_variables), dtype=float
    )  # type: ignore
    n_non_zero_linear_constraint_coefficients = int(_read_next_values(split_input)[0])
    for _ in range(n_non_zero_linear_constraint_coefficients):
        i, j, v = _read_next_values(split_input)[:3]
        linear_constraint_coefficients[int(i) - 1, int(j) - 1] = float(v)

    return sp.sparse.csr_matrix(linear_constraint_coefficients)


def _parse_variable_bounds(split_input: Iterator, num_variables: int) -> np.ndarray:
    default_bound = float(_read_next_values(split_input)[0])
    n_non_default_integer_bounds = int(_read_next_values(split_input)[0])
    bounds = np.full(num_variables, default_bound, dtype=int)
    for _ in range(n_non_default_integer_bounds):
        i, v = _read_next_values(split_input)[:2]
        try:
            bound = int(v)
        except ValueError:
            raise ValueError("Non-integer variable bounds are not supported.")
        bounds[int(i) - 1] = bound

    return bounds


def _parse_quadratic_coefficients(
    split_input: Iterator, num_quadratic_terms: int, num_variables: int
) -> sp.sparse.csr_array:
    quadratic_coefficients = sp.sparse.dok_array((num_variables, num_variables), dtype=float)
    for _ in range(num_quadratic_terms):
        i, j, v = _read_next_values(split_input)[:3]
        if i > j:  # Dev note: this should not be necessary if the qplib string is well formatted.
            i, j = j, i
        quadratic_coefficients[int(i) - 1, int(j) - 1] = float(v)
    return sp.sparse.csr_matrix(quadratic_coefficients)


def _parse_constraint_lower_bounds(
    split_input: Iterator, infinity: float, num_constraints: int
) -> np.ndarray:
    default_bound = float(_read_next_values(split_input)[0])
    n_non_default_bounds = int(_read_next_values(split_input)[0])
    bounds = np.full(num_constraints, default_bound, dtype=float)
    for _ in range(n_non_default_bounds):
        i, v = _read_next_values(split_input)[:2]
        bound = float(v)
        if bound <= -infinity:
            bound = -infinity

        bounds[int(i) - 1] = bound

    return bounds


def _parse_constraint_upper_bounds(
    split_input: Iterator, infinity: float, num_constraints: int
) -> np.ndarray:
    default_bound = float(_read_next_values(split_input)[0])
    n_non_default_bounds = int(_read_next_values(split_input)[0])
    bounds = np.full(num_constraints, default_bound, dtype=float)
    for _ in range(n_non_default_bounds):
        i, v = _read_next_values(split_input)[:2]
        bound = float(v)
        if bound >= infinity:
            bound = infinity

        bounds[int(i) - 1] = bound

    return bounds


def _parse_variable_starting_points(split_input: Iterator) -> DefaultDict:
    default = float(_read_next_values(split_input)[0])
    n_non_default = int(_read_next_values(split_input)[0])
    variable_starting_points = defaultdict(lambda: default)
    for _ in range(n_non_default):
        i, v = _read_next_values(split_input)[:2]
        variable_starting_points[int(i)] = float(v)
    return variable_starting_points


def _parse_penalty_strengths(split_input: Iterator, num_constraints: int) -> np.ndarray:
    default = float(_read_next_values(split_input)[0])  # noqa: F841
    n_non_default = int(_read_next_values(split_input)[0])
    penalty_strengths = np.full(num_constraints, default, dtype=float)
    for _ in range(n_non_default):
        i, v = _read_next_values(split_input)[:2]
        penalty_strengths[int(i) - 1] = float(v)
    return penalty_strengths


def _validate_model(model_type: str) -> Tuple[str, str, str]:
    if model_type[0] == "L":
        objective_type = "linear"
    elif model_type[0] == "Q":
        objective_type = "quadratic"
    else:
        raise ValueError(f"Unsupported objective type: {model_type[0]}.")

    if model_type[1] == "B":
        variable_type = "binary"
    elif model_type[1] == "I":
        variable_type = "integer"
    else:
        raise ValueError(f"Unsupported variable type: {model_type[1]}.")

    if model_type[2] == "L":
        constraint_type = "linear"
    elif model_type[2] == "B":
        constraint_type = "box"
    else:
        raise ValueError(f"Unsupported constraint type: {model_type[2]}.")

    return objective_type, variable_type, constraint_type


def deserialize_model(input_str: str) -> Tuple:
    """Deserializes a qplib str to recreate an sop model"""
    split_input = iter(input_str.splitlines())

    _read_next_values(split_input)  # name
    model_type = _read_next_values(split_input)[0]
    sense = _read_next_values(split_input)[0]
    num_variables = int(_read_next_values(split_input)[0])
    objective_type, variable_type, constraint_type = _validate_model(model_type)

    if constraint_type == "linear":
        num_constraints = int(_read_next_values(split_input)[0])
    else:
        num_constraints = 0

    if objective_type != "linear":
        num_quadratic_terms = int(_read_next_values(split_input)[0])
        quadratic_objective_matrix = _parse_quadratic_coefficients(
            split_input, num_quadratic_terms, num_variables
        )
    else:
        quadratic_objective_matrix = None

    linear_objective_vector = _parse_linear_coefficients(split_input, num_variables)
    constant = float(_read_next_values(split_input)[0])

    if constraint_type == "linear":
        linear_constraint_matrix = _parse_linear_constraint_coefficients(
            split_input, num_variables, num_constraints
        )
    else:
        linear_constraint_matrix = None

    infinity = float(_read_next_values(split_input)[0])
    if constraint_type == "linear":
        constraint_lower_bounds = _parse_constraint_lower_bounds(
            split_input, infinity, num_constraints
        )
        constraint_upper_bounds = _parse_constraint_upper_bounds(
            split_input, infinity, num_constraints
        )
    else:
        constraint_lower_bounds = None
        constraint_upper_bounds = None

    if variable_type == "binary":
        variable_lower_bounds = None
        variable_upper_bounds = None
    else:
        variable_lower_bounds = _parse_variable_bounds(split_input, num_variables)
        variable_upper_bounds = _parse_variable_bounds(split_input, num_variables)

    # Parse but ignore variable starting points.
    _ = _parse_variable_starting_points(split_input)

    # Penalty strengths are referred to as "starting values for Lagrange multipliers" in the QPLIB
    # documentation.
    if constraint_type != "box":
        penalty_strengths = _parse_penalty_strengths(split_input, num_constraints)
    else:
        penalty_strengths = None

    return (
        linear_objective_vector,
        quadratic_objective_matrix,
        constant,
        sense,
        variable_type,
        linear_constraint_matrix,
        constraint_lower_bounds,
        constraint_upper_bounds,
        variable_lower_bounds,
        variable_upper_bounds,
        penalty_strengths,
    )
