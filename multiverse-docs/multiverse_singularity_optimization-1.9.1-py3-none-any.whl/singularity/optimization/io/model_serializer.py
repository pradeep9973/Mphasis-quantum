# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

import numpy as np
import scipy as sp

from singularity.optimization.io.constants import INFINITY, NEGATIVE_INFINITY

CONSTRAINT_TYPES = {"linear": "L", "none": "N", "box": "B"}
VARIBALE_TYPES = {"binary": "B", "integer": "I", "continuous": "C", "mixed": "M"}
OBJECTIVE_TYPES = {"quadratic": "Q", "linear": "L"}


def serialize_model(model) -> str:
    """Serializes Model to qplib format."""
    model_type = (
        OBJECTIVE_TYPES[model.objective_type]
        + VARIBALE_TYPES[model.variable_type]
        + CONSTRAINT_TYPES[model.constraint_type]
    )

    newline = "\n"
    output_list = []

    output_list.extend(["ANON", model_type, model.sense, f"{model.num_variables}"])

    if model.constraint_type not in ("none", "box"):
        output_list.append(f"{model.num_constraints}")

    if model.objective_type != "linear":
        q_matrix_lower_triangular_coo = sp.sparse.coo_matrix(
            _convert_to_lower_triangular_form(model.quadratic_objective_matrix)
        )
        output_list.append(f"{q_matrix_lower_triangular_coo.nnz}")
        output_list.extend(
            (
                f"{row + 1} {col + 1} {coeff}"
                for row, col, coeff in zip(
                    q_matrix_lower_triangular_coo.row,
                    q_matrix_lower_triangular_coo.col,
                    q_matrix_lower_triangular_coo.data,
                )
            )
        )

    l_vector_coo = sp.sparse.coo_matrix(model.linear_objective_vector)
    output_list.extend(["0", f"{l_vector_coo.nnz}"])
    output_list.extend(
        (f"{col + 1} {coeff}" for col, coeff in zip(l_vector_coo.col, l_vector_coo.data))
    )
    output_list.append(f"{model.constant}")

    if model.constraint_type not in ("none", "box"):
        cons_matrix_coo = sp.sparse.coo_matrix(model.linear_constraint_matrix)
        output_list.append(f"{cons_matrix_coo.nnz}")
        output_list.extend(
            (
                f"{row + 1} {col + 1} {coeff}"
                for row, col, coeff in zip(
                    cons_matrix_coo.row, cons_matrix_coo.col, cons_matrix_coo.data
                )
            )
        )

    output_list.append(f"{INFINITY:.4E}")

    default_constraint_upper_bound = INFINITY
    default_constraint_lower_bound = NEGATIVE_INFINITY
    if model.constraint_type not in ("none", "box"):
        num_non_default_lower_bounds = np.count_nonzero(
            model.constraint_lower_bounds != default_constraint_lower_bound
        )
        num_non_default_upper_bounds = np.count_nonzero(
            model.constraint_upper_bounds != default_constraint_upper_bound
        )

        output_list.append(f"{default_constraint_lower_bound:.4E}")
        output_list.append(f"{num_non_default_lower_bounds}")
        output_list.extend(
            [
                f"{i + 1} {lb}"
                for i, lb in enumerate(model.constraint_lower_bounds)
                if lb != default_constraint_lower_bound
            ]
        )
        output_list.append(f"{default_constraint_upper_bound:.4E}")
        output_list.append(f"{num_non_default_upper_bounds}")
        output_list.extend(
            [
                f"{i + 1} {ub}"
                for i, ub in enumerate(model.constraint_upper_bounds)
                if ub != default_constraint_upper_bound
            ]
        )

    if model.variable_type != "binary":

        default_variable_lower_bound = 0
        default_variable_upper_bound = 1
        num_non_default_lower_variable_bounds = np.count_nonzero(
            model.variable_lower_bounds != default_variable_lower_bound
        )
        num_non_default_upper_variable_bounds = np.count_nonzero(
            model.variable_upper_bounds != default_variable_upper_bound
        )

        output_list.append(f"{default_variable_lower_bound}")
        output_list.append(f"{num_non_default_lower_variable_bounds}")
        output_list.extend(
            [
                f"{i + 1} {lb}"
                for i, lb in enumerate(model.variable_lower_bounds)
                if lb != default_variable_lower_bound
            ]
        )

        output_list.append(f"{default_variable_upper_bound}")
        output_list.append(f"{num_non_default_upper_variable_bounds}")
        output_list.extend(
            [
                f"{i + 1} {ub}"
                for i, ub in enumerate(model.variable_upper_bounds)
                if ub != default_variable_upper_bound
            ]
        )

    output_list.extend(
        [
            "1.0",  # default value for initial values for x
            "0",  # non default entries in x
        ]
    )

    if model.constraint_type not in ("none", "box"):
        default_penalty_strength = 10
        num_non_default_penalty_strengths = np.count_nonzero(
            model.penalty_strengths != default_penalty_strength
        )
        output_list.extend(
            [
                f"{default_penalty_strength}",  # default value for initial values for y
                f"{num_non_default_penalty_strengths}",  # non default entries in y
            ]
        )
        output_list.extend(
            [
                f"{i + 1} {penalty_strength}"
                for i, penalty_strength in enumerate(model.penalty_strengths)
                if penalty_strength != default_penalty_strength
            ]
        )
    output = newline.join(output_list)
    return output


def _convert_to_lower_triangular_form(q_matrix):
    return sp.sparse.tril(q_matrix) + sp.sparse.triu(q_matrix, k=1).T
