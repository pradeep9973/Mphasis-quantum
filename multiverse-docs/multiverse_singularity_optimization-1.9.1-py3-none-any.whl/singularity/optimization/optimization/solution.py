# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

import logging
from dataclasses import dataclass
from typing import Dict, Optional

from singularity.optimization.modelling.variable import Variable

logger = logging.getLogger("singularity.optimization")


@dataclass(frozen=True)
class Solution:
    """
    Solution data.

    The data are immutable.
    """

    variables: Dict[Variable, int]
    """Solution's variables and their values."""

    objective_value: float
    """The objective value of the solution"""

    is_feasible: bool
    """Feasibility of the solution."""

    num_occurrences: Optional[int] = None
    """When the solutions is sampled from a solution set, the number of occurrences."""

    @property
    def cost(self):
        """
        Solution's objective value.

        `sop.Solution`: `cost` is deprecated and will be removed in version `2.0.0`,
        use `objective_value` instead.
        """
        logger.info(
            "`sop.Solution`: `cost` is deprecated and will be removed in version `2.0.0`,"
            " use `objective_value` instead."
        )
        return self.objective_value

    @property
    def qpu_readout(self):
        """
        Solution's variables and their values.

        `sop.Solution`: `qpu_readout` is deprecated and will be removed in version `2.0.0`,
        use `variables` instead.
        """
        logger.info(
            "`sop.Solution`: `qpu_readout` is deprecated and will be removed in version `2.0.0`,"
            " use `variables` instead."
        )
        return self.variables
