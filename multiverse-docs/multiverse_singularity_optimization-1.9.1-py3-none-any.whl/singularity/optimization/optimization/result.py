# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

import warnings
from dataclasses import dataclass
from operator import attrgetter
from typing import Dict, List, Optional

from singularity.optimization.modelling.variable import Variable
from singularity.optimization.optimization.solution import Solution

warnings.formatwarning = lambda msg, *args, **kwargs: f"{args[0].__name__}: {msg}\n"


@dataclass(frozen=True)
class OptimizationResult:
    """Result of the optimization.

    The data are immutable.
    """

    # The order of the fields is intended to preserve retro compatibility with
    # systems that instantiate OptimizationResult objects directly.

    samples: List[Solution]
    """
    A list of generated samples for probabilistic solvers. These samples might represent infeasible
    solutions.
    """

    runtime: float
    """The time in seconds it took the optimization job to finish."""

    details: Optional[dict]
    """Additional solver-dependent information about the optimization process."""

    # New fields of the polished interface: values, objective_value, status

    values: Optional[Dict[Variable, float]] = None
    """Values of the best solution found by the solver. Is None if no feasible solution could be
    found."""

    objective_value: Optional[float] = None
    """Value of the objective function at the found solution. Is None if no feasible solution could
    be found."""

    status: Optional[str] = None
    """Status of the optimization process."""

    sense: str = "minimize"
    """The sense of the optimization problem"""

    def __post_init__(self):
        """Sort samples according to objective value and feasibility."""
        self.samples.sort(key=attrgetter("objective_value"), reverse=self.sense == "maximize")
        self.samples.sort(key=attrgetter("is_feasible"), reverse=True)

    #  Deprecated fields are added as properties, to be removed in version 2.0.0

    @property
    def solutions(self) -> List[Solution]:
        """Deprecated way to access the samples."""
        warnings.warn(
            "`solutions` is deprecated and might be removed in future versions. Please "
            "use `samples` instead.",
            FutureWarning,
        )
        return self.samples

    @property
    def optimizer_info(self) -> dict:
        """Deprecated way to access the details."""
        warnings.warn(
            "`optimizer_info` is deprecated and might be removed in future versions. "
            "Please use `details` instead.",
            FutureWarning,
        )
        return self.details

    @property
    def best(self) -> Solution:
        """Deprecated way to return best found solution (lowest cost)."""
        warnings.warn(
            "`best` is deprecated and might be removed in future versions. "
            "Please use `values` and `objective_value` instead.",
            FutureWarning,
        )
        return self.samples[0]

    @property
    def worst(self) -> Solution:
        """Worst found solution (highest cost). Its usage is deprecated."""
        warnings.warn(
            "`worst` is deprecated and might be removed in future versions.",
            FutureWarning,
        )
        return self.samples[-1]
