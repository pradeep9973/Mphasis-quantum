# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

from enum import Enum, unique


@unique
class ErrorCode(str, Enum):
    """Enum for error codes"""

    IO_ERROR = "IO_ERROR"
    VALIDATION_ERROR = "VALIDATION_ERROR"
    UNKNOWN_ERROR = "UNKNOWN_ERROR"
    HIGHSPY_ERROR = "HIGHSPY_ERROR"
    CLASSICAL_SOLVER_ERROR = "CLASSICAL_SOLVER_ERROR"
    NO_SOLUTION_ERROR = "NO_SOLUTION_ERROR"
    DWAVE_ERROR = "DWAVE_ERROR"
    TIMEOUT_ERROR = "TIMEOUT_ERROR"
    OPTIMIZATION_TIMEOUT_ERROR = "OPTIMIZATION_TIMEOUT_ERROR"
    AUTHORIZATION_ERROR = "NO_PERMISSION"


class SOPError(Exception):
    """SOP error"""

    def __init__(self, message="SOP error"):
        """SOP error"""
        self.message = message
        super().__init__(self.message)


class SOPValidationError(SOPError):
    """SOP backend validation failure"""

    def __init__(self, message="Validation error"):
        """Init Validation error"""
        self.message = message
        super().__init__(self.message)


class SOPIOError(SOPError):
    """SOP backend input-output failure (loading model, storing result)"""

    def __init__(self, message="IO error"):
        """Init IO error"""
        self.message = message
        super().__init__(self.message)


class SOPUnknownError(SOPError):
    """Fallback error"""

    def __init__(self, message="Unknown error"):
        """Init Unknown error"""
        self.message = message
        super().__init__(self.message)


class SOPClassicalSolverError(SOPError):
    """Classical solver error"""

    def __init__(
        self,
        message="classical engine encountered an error while looking for solutions",
    ):
        """Classical solver error"""
        self.message = message
        super().__init__(self.message)


class SOPNoSolutionError(SOPError):
    """No solution found error"""

    def __init__(
        self,
        message="0 feasible solutions were found for this problem.",
    ):
        """No solution error"""
        self.message = message
        super().__init__(self.message)


class SOPHighspyError(SOPError):
    """Highspy error"""

    def __init__(
        self,
        message="po_classical engine encountered an error while looking for solutions",
    ):
        """Init Highspy error"""
        self.message = message
        super().__init__(self.message)


class SOPDWaveError(SOPError):
    """DWAVE error"""

    def __init__(self, message="DWAVE error"):
        """Init DWave error"""
        self.message = message
        super().__init__(self.message)


class SOPTimeoutError(Exception):
    """Timeout error"""

    def __init__(self, message="TIMEOUT error"):
        """Init Timeout error"""
        self.message = message
        super().__init__(self.message)


class SOPOptimizationTimeoutError(SOPError):
    """SOP backend optimization Timeout error"""

    def __init__(self, message="Optimization TIMEOUT error"):
        """Init Optimization Timeout error"""
        self.message = message
        super().__init__(self.message)


class AuthorizationError(SOPError):
    """Authorization error"""

    def __init__(self, message="AUTHORIZATION error"):
        """Authorization error"""
        self.message = message
        super().__init__(self.message)


ERRORS_MAP = {
    ErrorCode.VALIDATION_ERROR: SOPValidationError,
    ErrorCode.IO_ERROR: SOPIOError,
    ErrorCode.UNKNOWN_ERROR: SOPUnknownError,
    ErrorCode.HIGHSPY_ERROR: SOPHighspyError,
    ErrorCode.CLASSICAL_SOLVER_ERROR: SOPClassicalSolverError,
    ErrorCode.NO_SOLUTION_ERROR: SOPNoSolutionError,
    ErrorCode.DWAVE_ERROR: SOPDWaveError,
    ErrorCode.TIMEOUT_ERROR: SOPTimeoutError,
    ErrorCode.OPTIMIZATION_TIMEOUT_ERROR: SOPOptimizationTimeoutError,
    ErrorCode.AUTHORIZATION_ERROR: AuthorizationError,
}
