# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

import logging

import singularity.optimization as sop

logging.basicConfig(level=logging.DEBUG)

if __name__ == "__main__":
    capacity = 10
    x1 = sop.Variable("x1", sop.INTEGER, (0, 10))
    x2 = sop.Variable("x2", sop.INTEGER, (0, 10))
    x3 = sop.Variable("x3", sop.INTEGER, (0, 10))
    x4 = sop.Variable("x4", sop.INTEGER, (0, 10))

    returns = -(x1 * 2.739 + x2 * -4.604 + x3 * -9.181 + x4 * -9.669)
    risk_aversion = 1  # range -> 0 to ∞
    risk = (
        0.5276 * x1**2
        + 0.069 * x2**2
        + 0.1605 * x3**2
        + 0.0239 * x4**2
        + 2
        * (
            0.0403 * x1 * x2
            + 0.1038 * x1 * x3
            + 0.0750 * x1 * x4
            + 0.158 * x2 * x3
            + 0.0029 * x2 * x4
            + 0.0043 * x3 * x4
        )
    )
    total_profit = risk * risk_aversion - returns

    total_weight = x1 + x2 + x3 + x4
    capacity_constraint = sop.Constraint(
        lhs=total_weight,
        operator="==",
        rhs=capacity,
        penalty_strength=10,
        name="capacity_constraint",
    )
    objective = sop.Objective(total_profit, "minimize")
    po_problem = sop.Model(objective)
    po_problem.add_constraint(capacity_constraint)
    result = po_problem.optimize(solver="classical", num_solutions=1)
    print(result)
