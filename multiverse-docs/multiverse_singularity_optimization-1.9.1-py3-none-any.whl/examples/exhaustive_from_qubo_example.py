# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

import logging

import singularity.optimization as sop

logging.basicConfig(level=logging.DEBUG)

if __name__ == "__main__":
    qubo = {
            (2, 3): 4.0,
            (1, 1): -3.0,
            (1, 2): -2.0,
            (1, 3): 3.0,
            (3, 3): 6.0,
            (2, 2): -2.0,
        }

    model = sop.Model.from_qubo(qubo, sense="maximize")
    result = model.optimize(solver="exhaustive", num_solutions=6)
    # Optimal Solution: values={x1: 0, x2: 1, x3: 1}, objective_value=8.0
    print(result)