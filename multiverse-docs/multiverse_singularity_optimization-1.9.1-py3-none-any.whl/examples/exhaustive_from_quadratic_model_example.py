# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

import logging

import scipy as sp

import singularity.optimization as sop

logging.basicConfig(level=logging.DEBUG)

if __name__ == "__main__":

    quadratic_coefficients = sp.sparse.dok_matrix((6, 6))
    quadratic_coefficients[0, 3] = 0.2
    quadratic_coefficients[4, 5] = -3.2
    quadratic_coefficients[3, 4] = 3.0
    quadratic_coefficients[1, 4] = 2.2
    quadratic_coefficients[0, 4] = -1.0
    quadratic_coefficients[1, 3] = -2.4
    quadratic_coefficients[2, 4] = 1.4
    quadratic_coefficients[0, 2] = -4.0

    model = sop.Model.from_quadratic_model(
        linear_objective_vector=sp.sparse.csr_matrix([[1.0, -1.0, -0.5, 1.7, -1.4, 1.9]]),
        quadratic_objective_matrix=sp.sparse.csr_matrix(quadratic_coefficients),
        variable_type="binary",
    )
    result = model.optimize(solver="exhaustive", num_solutions=6)
    # Optimal Solution: values={x0: 1, x1: 0, x2: 1, x3: 0, x4: 1, x5: 0}, objective_value=-2.7
    print(result)