# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

import logging

import singularity.optimization as sop

logging.basicConfig(level=logging.DEBUG)

if __name__ == "__main__":
    capacity = 10
    x0 = sop.Variable("x0", sop.INTEGER, (5, 90))
    x1 = sop.Variable("x1", sop.INTEGER, (10, 20))
    x2 = sop.Variable("x2", sop.INTEGER, (0, 90))
    objective_expression = (-6e-05 * x0 - 0.00057 * x1 - 6e-05 * x2 +
                            0.003 * x0 * x2 + 0.002 * x1 * x0 + 0.004 * x1 * x2 +
                            0.0025 * x0 ** 2 + 0.003 * x1 ** 2 + 0.0035 * x2 ** 2)

    objective = sop.Objective(objective_expression, sense="minimize")

    constraint_0 = sop.Constraint(
        lhs=-100 + 1.0 * x0 + 1.0 * x1 + 1.0 * x2,
        operator="==",
        rhs=0,
        penalty_strength=100,
        name="total_holding_constraint"
    )

    constraint_1 = sop.Constraint(
        lhs=-50.0 + 1.0 * x0,
        operator=">=",
        rhs=0,
        penalty_strength=100,
        name="custom_constraint_1"
    )

    constraint_2 = sop.Constraint(
        lhs=1.0 * x1 - 1.5 * x2,
        operator=">=",
        rhs=0,
        penalty_strength=100,
        name="custom_constraint_2"
    )
    constraints = [constraint_0, constraint_1, constraint_2]

    model = sop.Model(objective=objective, constraints=constraints)
    result = model.optimize(solver="po_classical")
    print(result)
