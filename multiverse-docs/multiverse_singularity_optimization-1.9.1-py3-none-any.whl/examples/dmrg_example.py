# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

import logging

import singularity.optimization as sop

logging.basicConfig(level=logging.DEBUG)

if __name__ == "__main__":
    capacity = 5
    x1 = sop.Variable("x1")
    x2 = sop.Variable("x2")
    x3 = sop.Variable("x3")
    total_profit = 2 * x1**2 + 3 * x2**2 + 6 * x3**2 + 2 * x1 * x2 + 4 * x1 * x3 + 3 * x2 * x3
    total_weight = 4 * x1 + 5 * x2 + 1 * x3
    capacity_constraint = sop.Constraint(
        lhs=total_weight,
        operator="<=",
        rhs=capacity,
        penalty_strength=10,
        name="capacity_constraint",
    )
    objective = sop.Objective(total_profit, "maximize")
    knapsack = sop.Model(objective)
    knapsack.add_constraint(capacity_constraint)

    parameters = {
        "max_bond_dimension": 10,
        "max_num_symmetries": 1,
        "max_num_sweeps": 10,
        "singular_value_cutoff": 10**-10,
    }

    result = knapsack.optimize(
        solver="tensor_network_experimental",
        num_solutions=1,
        **parameters,
    )
    print(result.samples)
