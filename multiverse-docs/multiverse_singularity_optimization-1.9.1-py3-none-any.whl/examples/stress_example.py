# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.
import argparse
import logging

import numpy as np
import scipy.stats

import singularity.optimization as sop

"""
This file contains functions to generate generic portfolio optimization problems of arbitrary size.
These are not real problem but synthetic ones that are mathematically identical. The generated
arrays are dense.
"""


class SyntheticPOProblem:
    def __init__(
        self, num_assets: int, seed: int, resolution: float = 0.01, risk_aversion: float = 50.0
    ):
        self.num_assets = num_assets
        self.seed = seed
        self.rng = np.random.default_rng(self.seed)
        self.resolution = resolution
        self.risk_aversion = risk_aversion

    def _gen_rand_array(self, dim, beta=False) -> np.ndarray:
        if beta:
            # alpha, beta chosen arbitrarily (skewed towards smaller values)
            return self.rng.beta(1, 5, size=dim)
        return 2.0 * (self.rng.random(dim) - 0.5)

    def _gen_correlation_matrix(self) -> np.ndarray:
        eigvals = self._gen_rand_array(self.num_assets, beta=True)
        # sum of eigvals must equal dimensionality
        eigvals = eigvals / np.sum(eigvals) * self.num_assets
        return scipy.stats.random_correlation.rvs(eigvals)

    def _gen_volatilities(self) -> np.ndarray:
        return abs(self._gen_rand_array(self.num_assets)) / 10.0

    def _gen_returns(self) -> np.ndarray:
        return self._gen_rand_array(self.num_assets) / 10.0

    def _gen_covariance_matrix(self) -> np.ndarray:
        correlation_matrix = self._gen_correlation_matrix()
        volatilities = self._gen_volatilities()
        vol_diag = np.diag(volatilities)
        return vol_diag @ correlation_matrix @ vol_diag

    def get_model(self) -> sop.Model:
        tot_holdings = int(1.0 / self.resolution)
        variables = (
            np.array(
                [
                    sop.Variable(f"x_{i}", sop.INTEGER, bounds=(0, tot_holdings))
                    for i in range(self.num_assets)
                ]
            )
            / tot_holdings
        )

        objective_expr = (
            -variables @ self._gen_returns()
            + self.risk_aversion * variables @ self._gen_covariance_matrix() @ variables
        )
        objective = sop.Objective(objective_expr, sense="minimize")

        tot_holding_constr_expr = tot_holdings * variables @ np.ones(self.num_assets)
        constraints = [
            sop.Constraint(
                lhs=tot_holding_constr_expr,
                operator="==",
                rhs=tot_holdings,
                penalty_strength=100,
                name="total_holding_constraint",
            )
        ]
        return sop.Model(objective, constraints=constraints)


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s [%(levelname)s]: %(message)s')
    parser = argparse.ArgumentParser(
        description="Generate random-generic portfolio optimization problems of arbitrary size. The generated arrays are dense."
    )
    parser.add_argument("-s", "--seed", help="The seed used for `random`.", type=int, default=0)
    parser.add_argument(
        "-n", "--num-assets", help="The number of assets to optimize for.", type=int, default=100
    )
    parser.add_argument("--solver", help="Solver name.", default="po_classical")
    parser.add_argument("--dry", help="Dry run, just generate the payload do not run the optimizer.", action='store_true')
    args = parser.parse_args()
    random_po = SyntheticPOProblem(args.num_assets, args.seed)
    model = random_po.get_model()
    if args.dry:
        payload = f"mod-{args.solver}-{args.num_assets}.json"
        model._dump_json(payload, solver=args.solver)
        print(f"Payload saved at `{payload}`.")
        exit()
    result = model.optimize(solver=args.solver)
    print(f"{result=}")
    print(sum(result.samples[0].variables.values()))
    print(sum(i for i in result.samples[0].variables.values()))
