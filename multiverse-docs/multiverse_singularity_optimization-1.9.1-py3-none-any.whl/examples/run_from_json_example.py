# Copyright 2022 Multiverse Computing
#
# You may not use this file except in compliance with the License.
# See LICENSE.md that came with this distribution for license information.

import argparse
import logging
import timeit

from singularity.optimization import Model

logging.basicConfig(level=logging.DEBUG)

if __name__ == "__main__":
    start_time = timeit.default_timer()

    parser = argparse.ArgumentParser()
    parser.add_argument('--file', nargs='?', default="examples/job_example.json", type=str)  
    args = parser.parse_args()

    model, optimizer_kwargs = Model.from_json(args.file)
    result = model.optimize(**optimizer_kwargs)

    runtime = timeit.default_timer() - start_time

    print(result)
    print("Runtime:", runtime)
