from .common import Benchmark
from asv_runner.benchmarks.mark import skip_for_params


class PortfolioOptimizationBenchmark(Benchmark):
    benchmark = ["test_01025.json", "test_01026.json", "test_01029.jso"]
    objective_reference = {"test_01025_baseline": -0.09853,
                           "test_01026_baseline": -0.07047,
                           "test_01029_baseline": -0.09901}
    baseline = list(objective_reference.keys())
    skip_list = [(bench, ) for bench in objective_reference.keys()]
    param_names = ["model"]
    params = benchmark + baseline

    def __init__(self):
        super().__init__(folder="po")

    def setup_cache(self):
        """Setup backup jsons"""
        super().setup_cache()

    def setup(self, model):
        """
        The wrapper method for setting up the problem
        """
        super().setup(model)

    def _time_base(self, problem):
        super()._time_base(problem)

    def _track_base(self, problem):
        super()._track_base(problem)


class PoClassicalSolver(PortfolioOptimizationBenchmark):
    #timeout = 1800

    def setup(self, model):
        super().setup(model)
        if self.payload:
            model, parameters = self.payload
            parameters["solver"] = "po_classical"
            parameters["num_solutions"] = 5
            parameters["timeout"] = 1800

    @skip_for_params(PortfolioOptimizationBenchmark.skip_list)
    def time_execution(self, problem):
        super()._time_base(problem)

    def track_objective(self, problem):
        return super()._track_base(problem)


class MultiverseHybridSolver(PortfolioOptimizationBenchmark):
    #timeout = 1800

    def setup(self, model):
        super().setup(model)
        if self.payload:
            model, parameters = self.payload
            parameters["solver"] = "multiverse_hybrid"
            parameters["num_solutions"] = 5
            parameters["timeout"] = 1800

    @skip_for_params(PortfolioOptimizationBenchmark.skip_list)
    def time_execution(self, problem):
        super()._time_base(problem)

    def track_objective(self, problem):
        return super()._track_base(problem)


class DMRGSolver(PortfolioOptimizationBenchmark):
    #timeout = 1800

    def setup(self, model):
        super().setup(model)
        if self.payload:
            model, parameters = self.payload
            parameters["solver"] = "tensor_network_experimental"
            parameters["num_solutions"] = 5
            parameters["timeout"] = 1800

    @skip_for_params(PortfolioOptimizationBenchmark.skip_list)
    def time_execution(self, problem):
        super()._time_base(problem)

    def track_objective(self, problem):
        return super()._track_base(problem)
