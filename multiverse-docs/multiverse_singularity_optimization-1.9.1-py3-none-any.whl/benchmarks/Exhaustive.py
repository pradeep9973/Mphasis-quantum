from .common import Benchmark
from asv_runner.benchmarks.mark import skip_for_params


class ExhaustiveBenchmark(Benchmark):
    benchmark = ["test_00003.json", "test_00300.json"]
    objective_reference = {"test_00003_baseline": -9.25664403589056,
                           "test_00300_baseline": 12.}
    baseline = list(objective_reference.keys())
    skip_list = [(bench,) for bench in objective_reference.keys()]
    param_names = ["model"]
    params = benchmark + baseline

    def __init__(self, folder=""):
        super().__init__(folder="exhaustive")

    def setup_cache(self):
        """Setup backup jsons"""
        super().setup_cache()

    def setup(self, model):
        """
        The wrapper method for setting up the problem
        """
        super().setup(model)

    def _time_base(self, problem):
        super()._time_base(problem)

    def _track_base(self, problem):
        return super()._track_base(problem)


class ExhaustiveSolver(ExhaustiveBenchmark):
    #timeout = 1800

    def setup(self, model):
        super().setup(model)
        if self.payload:
            model, parameters = self.payload
            parameters["solver"] = "exhaustive"
            parameters["num_solutions"] = 5
            parameters["timeout"] = 1800

    @skip_for_params(ExhaustiveBenchmark.skip_list)
    def time_execution(self, problem):
        super()._time_base(problem)

    def track_objective(self, problem):
        return super()._track_base(problem)


class TensorNetworkSolver(ExhaustiveBenchmark):
    #timeout = 1800

    def setup(self, model):
        super().setup(model)
        if self.payload:
            model, parameters = self.payload
            parameters["solver"] = "tensor_network"
            parameters["num_solutions"] = 5
            parameters["timeout"] = 1800
            tn_parameters = {
                "trotter_delta": 2.0,
                "trotter_steps": 50,
                "evolution_length": 10,
                "scheduler": "adaptive_trotter",
                "max_bond_dimension": 15,
                "number_of_adaptive_penalty_iterations": 10,
                "penalty_multiplier": 4.0,
            }
            parameters.update(tn_parameters)

    @skip_for_params(ExhaustiveBenchmark.skip_list)
    def time_execution(self, problem):
        super()._time_base(problem)

    def track_objective(self, problem):
        return super()._track_base(problem)


class DwaveExactSolver(ExhaustiveBenchmark):
    #timeout = 3600

    def setup(self, model):
        super().setup(model)
        if self.payload:
            model, parameters = self.payload
            parameters["solver"] = "dwave_exact"
            parameters["num_solutions"] = 5
            parameters["timeout"] = 1800

    @skip_for_params(ExhaustiveBenchmark.skip_list)
    def time_execution(self, problem):
        super()._time_base(problem)

    def track_objective(self, problem):
        return super()._track_base(problem)


class DwaveSimulatedAnnealingSolver(ExhaustiveBenchmark):
    def setup(self, model):
        super().setup(model)
        if self.payload:
            model, parameters = self.payload
            parameters["solver"] = "simulated_annealing"
            parameters["num_solutions"] = 5
            parameters["timeout"] = 1800

    @skip_for_params(ExhaustiveBenchmark.skip_list)
    def time_execution(self, problem):
        super()._time_base(problem)

    def track_objective(self, problem):
        return super()._track_base(problem)


class DwaveQpuSolver(ExhaustiveBenchmark):
    def setup(self, model):
        super().setup(model)
        if self.payload:
            model, parameters = self.payload
            parameters["solver"] = "dwave_qpu"
            parameters["num_solutions"] = 5
            parameters["timeout"] = 1800

    @skip_for_params(ExhaustiveBenchmark.skip_list)
    def time_execution(self, problem):
        super()._time_base(problem)

    def track_objective(self, problem):
        return super()._track_base(problem)
