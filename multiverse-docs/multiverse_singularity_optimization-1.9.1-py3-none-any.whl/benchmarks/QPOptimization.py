from .common import Benchmark
from asv_runner.benchmarks.mark import skip_for_params


class QPBenchmark(Benchmark):
    benchmark = ["test_00025.json", "test_00134.json", "test_00139.json",
                 "test_00149.json", "test_00152.json", "test_00153.json",
                 "test_00154.json", "test_00155.json", "test_00156.json",
                 "test_00157.json", "test_00158.json"
                 ]
    objective_reference = {"test_00025_baseline": 13067.,
                           "test_00134_baseline": 1198.,
                           "test_00139_baseline": -1.165682,
                           "test_00149_baseline": 7008.,
                           "test_00152_baseline": 375818.,
                           "test_00153_baseline": 1183.,
                           "test_00154_baseline": 1829.,
                           "test_00155_baseline": 0.,
                           "test_00156_baseline": 56161.9323,
                           "test_00157_baseline": -29432.,
                           "test_00158_baseline": 2377.
                           }
    baseline = list(objective_reference.keys())
    skip_list = [(bench,) for bench in objective_reference.keys()]
    param_names = ["model"]
    params = benchmark + baseline

    def __init__(self):
        super().__init__(folder="qp")

    def setup_cache(self):
        """Setup backup jsons"""
        super().setup_cache()

    def setup(self, model):
        """
        The wrapper method for setting up the problem
        """
        super().setup(model)

    def _time_base(self, problem):
        super()._time_base(problem)

    def _track_base(self, problem):
        super()._track_base(problem)


class TensorNetworkSolver(QPBenchmark):
    #timeout = 1000

    def setup(self, model):
        super().setup(model)
        if self.payload:
            model, parameters = self.payload
            parameters["solver"] = "tensor_network"
            parameters["num_solutions"] = 5
            parameters["timeout"] = 1800
            tn_parameters = {
                "trotter_delta": 2.0,
                "trotter_steps": 50,
                "evolution_length": 10,
                "scheduler": "adaptive_trotter",
                "max_bond_dimension": 15,
                "number_of_adaptive_penalty_iterations": 10,
                "penalty_multiplier": 4.0,
            }
            parameters.update(tn_parameters)

    @skip_for_params(QPBenchmark.skip_list)
    def time_execution(self, problem):
        super()._time_base(problem)

    def track_objective(self, problem):
        return super()._track_base(problem)


class DwaveExactSolver(QPBenchmark):
    #timeout = 1000

    def setup(self, model):
        super().setup(model)
        if self.payload:
            model, parameters = self.payload
            parameters["solver"] = "dwave_exact"
            parameters["num_solutions"] = 5
            parameters["timeout"] = 1800

    @skip_for_params(QPBenchmark.skip_list)
    def time_execution(self, problem):
        super()._time_base(problem)

    def track_objective(self, problem):
        return super()._track_base(problem)


class DwaveSimulatedAnnealingSolver(QPBenchmark):
    def setup(self, model):
        super().setup(model)
        if self.payload:
            model, parameters = self.payload
            parameters["solver"] = "simulated_annealing"
            parameters["num_solutions"] = 5
            parameters["timeout"] = 1800

    @skip_for_params(QPBenchmark.skip_list)
    def time_execution(self, problem):
        super()._time_base(problem)

    def track_objective(self, problem):
        return super()._track_base(problem)


class DwaveQpuSolver(QPBenchmark):
    def setup(self, model):
        super().setup(model)
        if self.payload:
            model, parameters = self.payload
            parameters["solver"] = "dwave_qpu"
            parameters["num_solutions"] = 5
            parameters["timeout"] = 1800

    @skip_for_params(QPBenchmark.skip_list)
    def time_execution(self, problem):
        super()._time_base(problem)

    def track_objective(self, problem):
        return super()._track_base(problem)
