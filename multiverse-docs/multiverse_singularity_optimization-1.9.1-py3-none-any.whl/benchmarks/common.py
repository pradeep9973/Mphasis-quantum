from pathlib import Path
import json
import singularity.optimization as sop


class Benchmark:
    benchmark = []
    objective_reference = {}
    rounds = 1
    repeat = (1, 2, 3)
    timeout = 120
    number = 1
    def __init__(self, folder=""):
        self.source_folder = folder

    def setup_cache(self):
        """Setup backup jsons"""
        for model in self.__class__.benchmark:
            root = Path(__file__).parent / self.source_folder
            with open(str(root / model)) as f:
                problem = json.load(f)
                if "hyperparameters" not in problem:
                    problem["hyperparameters"] = {"solver_options": {}}
                model_number = model[:model.index(".json")]
                with open(str(root / (model_number + "_backup.json")), "w") as f:
                    json.dump(problem, f)

    def setup(self, model):
        """
        The wrapper method for setting up the problem
        """
        self.payload = None
        if model in self.__class__.objective_reference:
            return
        self.root = Path(__file__).parent / self.source_folder
        model_number = model[:model.index(".json")]
        self.payload = sop.Model.from_json(str(self.root / (model_number + "_backup.json")))

    def _time_base(self, problem):
        model, parameters = self.payload
        model.optimize(**parameters)

    def _track_base(self, problem):
        res = self.__class__.objective_reference.get(problem)
        if res or res == 0.0:
            return res
        model, parameters = self.payload
        results = model.optimize(**parameters)
        return results.objective_value
